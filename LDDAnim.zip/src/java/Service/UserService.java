package Service;

import Model.Kapcsolat;
import Model.User;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;

public class UserService {
    //Login query of User table
    public User login(String userName, String password) {
        User user = null; //Placeholder user for error signal
        try {
            StoredProcedureQuery loginQuery = new Kapcsolat().getEntityManager().createStoredProcedureQuery("login");
            loginQuery.registerStoredProcedureParameter("userNameIN", String.class, ParameterMode.IN);
            loginQuery.registerStoredProcedureParameter("passwordIN", String.class, ParameterMode.IN);
            loginQuery.registerStoredProcedureParameter("userIDOUT", String.class, ParameterMode.OUT);
            loginQuery.setParameter("userNameIN", userName);
            loginQuery.setParameter("passwordIN", password);
            loginQuery.execute();
            Integer userID = Integer.parseInt(loginQuery.getOutputParameterValue("userIDOUT").toString());
            user = new Kapcsolat().getEntityManager().find(User.class, userID);
        }
        catch (Exception e) {
            System.out.println(e.toString() + " ERROR: login query failed at UserService");
        }
        return user;
    }   
    //Registered query of User table
    public Integer isRegistered(String userName, String password, String email) {
        Integer registeredUserCount = 0;
        try {
            StoredProcedureQuery isRegisteredQuery = new Kapcsolat().getEntityManager().createStoredProcedureQuery("isRegistered");
            isRegisteredQuery.registerStoredProcedureParameter("userNameIN", String.class, ParameterMode.IN);
            isRegisteredQuery.registerStoredProcedureParameter("passwordIN", String.class, ParameterMode.IN);
            isRegisteredQuery.registerStoredProcedureParameter("emailIN", String.class, ParameterMode.IN);
            isRegisteredQuery.registerStoredProcedureParameter("registeredUserCountOUT", Integer.class, ParameterMode.OUT);
            isRegisteredQuery.setParameter("userNameIN", userName);
            isRegisteredQuery.setParameter("passwordIN", password);
            isRegisteredQuery.setParameter("emailIN", email);
            isRegisteredQuery.execute();
            registeredUserCount = Integer.parseInt(isRegisteredQuery.getOutputParameterValue("registeredUserCountOUT").toString());            
        }
        catch (Exception e) {
            System.out.println(e.toString() + " ERROR: user is already registered query failed at UserService");
        }
        return registeredUserCount;
    }   
    //Add new user query of User table
    public User addNewUser(String userName, 
                           String password, 
                           String email, 
                           String givenName, 
                           String surName, 
                           String address, 
                           String city, 
                           String zip, 
                           String country) {
        User user = null; //Placeholder user for error signal
        try {
            StoredProcedureQuery addNewUserQuery = new Kapcsolat().getEntityManager().createStoredProcedureQuery("addNewUser");
            addNewUserQuery.registerStoredProcedureParameter("userNameIN", String.class, ParameterMode.IN);
            addNewUserQuery.registerStoredProcedureParameter("passwordIN", String.class, ParameterMode.IN);
            addNewUserQuery.registerStoredProcedureParameter("emailIN", String.class, ParameterMode.IN);
            addNewUserQuery.registerStoredProcedureParameter("givenNameIN", String.class, ParameterMode.IN);
            addNewUserQuery.registerStoredProcedureParameter("surNameIN", String.class, ParameterMode.IN);
            addNewUserQuery.registerStoredProcedureParameter("addressIN", String.class, ParameterMode.IN);
            addNewUserQuery.registerStoredProcedureParameter("cityIN", String.class, ParameterMode.IN);
            addNewUserQuery.registerStoredProcedureParameter("zipIN", String.class, ParameterMode.IN);
            addNewUserQuery.registerStoredProcedureParameter("countryIN", String.class, ParameterMode.IN);
            addNewUserQuery.setParameter("userNameIN", userName);
            addNewUserQuery.setParameter("passwordIN", password);
            addNewUserQuery.setParameter("emailIN", email);
            addNewUserQuery.setParameter("givenNameIN", givenName);
            addNewUserQuery.setParameter("surNameIN", surName);
            addNewUserQuery.setParameter("addressIN", address);
            addNewUserQuery.setParameter("cityIN", city);
            addNewUserQuery.setParameter("zipIN", zip);
            addNewUserQuery.setParameter("countryIN", country);
            addNewUserQuery.execute();
            user = login(userName, password);
        }
        catch (Exception e) {
            System.out.println(e.toString() + " ERROR: add new user query failed at UserService");
        }
        return user;
    }
}
