package Service;

import Model.Anim;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONObject;

public class AnimService {

    public Boolean addNewAnim(String titleTxt, String authorTxt, String versionTxt, String frameCountTxt) {
        //Bemenő paraméter validáció
        String title = null;
        String author = null;
        Integer version = null;
        Integer frameCount = null;
        try {
            title = titleTxt;
            author = authorTxt;
            version = Integer.parseInt(versionTxt);
            frameCount = Integer.parseInt(frameCountTxt);
        }
        catch (Exception e) {
            throw new RuntimeException(e.toString() + "Error:Service:Validation:addNewAnim");
        }
        //Model osztály példányosítás
        Anim anim = new Anim(0, title, author, version, frameCount); //Kamu animID
        //Művelet, sikerjelzés visszaadása
        return anim.addNewAnim();
    }
    
    public JSONArray getAnim(String animIDTxt) {
        //Bemenő paraméter validáció
        Integer animID = null;
        try {
            animID = Integer.parseInt(animIDTxt);
        }
        catch (Exception e) {
            throw new RuntimeException(e.toString() + "Error:Service:Validation:getAnim");
        }
        //Model osztály példányosítás
        Anim anim = new Anim(animID, " ", " ", 0, 0); //Minden kamu kiv. animID
        //Művelet, sikerjelzés visszaadása
        JSONObject jRecord = new JSONObject();
        List <JSONObject> jTabla = new ArrayList();
        if(anim.getAnim()) {
            jRecord.put("animID", anim.getAnimID());
            jRecord.put("title", anim.getTitle());
            jRecord.put("author", anim.getAuthor());
            jRecord.put("version", anim.getVersion());
            jRecord.put("frameCount", anim.getFrameCount());
        }
        else {
            jRecord.put("animID", "");
            jRecord.put("title", "");
            jRecord.put("author", "");
            jRecord.put("version", "");
            jRecord.put("frameCount", "");            
        }
        jTabla.add(jRecord);
        return JsonConvert.toJSONArray(jTabla);
    }
    
    public Boolean updateAnim(String animIDTxt, String titleTxt, String versionTxt, String frameCountTxt) {
        //Bemenő paraméter validáció
        Integer animID = null;
        String title = null;
        Integer version = null;
        Integer frameCount = null;
        try {
            animID = Integer.parseInt(animIDTxt);
            title = titleTxt;
            version = Integer.parseInt(versionTxt);
            frameCount = Integer.parseInt(frameCountTxt);
        }
        catch (Exception e) {
            throw new RuntimeException(e.toString() + "Error:Service:Validation:updateAnim");
        }
        //Model osztály példányosítás
        Anim anim = new Anim(animID, title, " ", version, frameCount);
        //Művelet, sikerjelzés visszaadása
        return anim.updateAnim();        
    }
    
    public Boolean deleteAnim(String animIDTxt) {
        //Bemenő paraméter validáció
        Integer animID = null;
        try {
            animID = Integer.parseInt(animIDTxt);
        }
        catch (Exception e) {
            throw new RuntimeException(e.toString() + "Error:Service:Validation:deleteAnim");
        }
        //Model osztály példányosítás
        Anim anim = new Anim(animID, " ", " ", 0, 0);
        //Művelet, sikerjelzés visszaadása
        return anim.deleteAnim();        
    }
    
    public JSONArray getAllAnim() {
        List <JSONObject> jTabla = new ArrayList();
        try {
            //Model osztály statikus hívás
            List <Anim> anims = Anim.getAllAnim();
            //Művelet, sikerjelzés visszaadása
            for(Anim anim: anims) {
                JSONObject jRecord = new JSONObject();
                jRecord.put("animID", anim.getAnimID());
                jRecord.put("title", anim.getTitle());
                jRecord.put("author", anim.getAuthor());
                jRecord.put("version", anim.getVersion());
                jRecord.put("frameCount", anim.getFrameCount());                
                jTabla.add(jRecord);                
            }
            return JsonConvert.toJSONArray(jTabla);
        }
        catch (Exception e) {
            throw new RuntimeException(e.toString() + " Error:Service:getAllAnim");
        }               
    }
}
