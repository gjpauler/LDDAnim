package Service;

import java.util.List;
import org.json.JSONArray;
import org.json.JSONObject;

public class JsonConvert {

    public static JSONArray toJSONArray(List<JSONObject> lista) {
        JSONArray array = new JSONArray();
        for (JSONObject obj : lista) {
            array.put(obj);
        }
        return array;
    }    
}
