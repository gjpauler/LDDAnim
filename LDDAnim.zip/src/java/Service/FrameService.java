package Service;

import Model.Anim;
import Model.Frame;
import Model.FrameFile;
import Model.Kapcsolat;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.EntityManager;
import org.json.JSONArray;
import org.json.JSONObject;

public class FrameService {
    
    //CRUD+A
    public Boolean addNewFrame(String frameIDTxt, 
                               String frameSeqTxt, 
                               String camFieldTxt, 
                               String camDistTxt, 
                               String camXTxt, 
                               String camYTxt, 
                               String camZTxt, 
                               String camRXTxt, 
                               String camRYTxt, 
                               String camRZTxt, 
                               String commandTxt, 
                               String param1Txt, 
                               String param2Txt, 
                               String param3Txt,
                               String animIDTxt) {
        Boolean oK = false;
        try {
            //Parameter validation
           Integer frameID = Integer.parseInt(frameIDTxt); 
           Integer frameSeq = Integer.parseInt(frameSeqTxt); 
           Double camField = Double.parseDouble(camFieldTxt); 
           Double camDist = Double.parseDouble(camDistTxt); 
           Double camX = Double.parseDouble(camXTxt); 
           Double camY = Double.parseDouble(camYTxt); 
           Double camZ = Double.parseDouble(camZTxt); 
           Double camRX = Double.parseDouble(camRXTxt); 
           Double camRY = Double.parseDouble(camRYTxt); 
           Double camRZ = Double.parseDouble(camRZTxt); 
           Double param1 = Double.parseDouble(param1Txt); 
           Double param2 = Double.parseDouble(param2Txt); 
           Double param3 = Double.parseDouble(param3Txt);
           Integer animID = Integer.parseInt(animIDTxt);           
            //Instancing 1 side class
            EntityManager em = new Kapcsolat().getEntityManager();
            Anim anim = em.find(Anim.class, animID);
            //Instancing many side class
            Frame frame = new Frame(frameID,
                                    frameSeq,
                                    camField,
                                    camDist,
                                    camX, 
                                    camY,
                                    camZ,
                                    camRX,
                                    camRY,
                                    camRZ,
                                    commandTxt,
                                    param1,
                                    param2,
                                    param3,
                                    anim);
            //Execute query
            oK = frame.addNewFrame();
        }
        catch (Exception e) {
            System.out.println(e.toString() + " ERROR: Frame Service: AddNewFrame");
        }
        return oK;
    }

    public JSONArray getFrame(String frameIDTxt) {
        Boolean oK = false;
        JSONObject jRecord = new JSONObject();
        List <JSONObject> jTabla = new ArrayList();
        try {
            //Parameter validation
            Integer frameID = Integer.parseInt(frameIDTxt);
            //Innstancing class
            Frame frame = new Frame(frameID, 
                                    0,
                                    0.0, 
                                    0.0,
                                    0.0,
                                    0.0,
                                    0.0,
                                    0.0,
                                    0.0,
                                    0.0,
                                    " ", 
                                    0.0, 
                                    0.0,
                                    0.0,
                                    null); //All fake except frameID
            //Execute command, success/unsuccess flag
            if(frame.getFrame()) {
                jRecord.put("frameID", frame.getFrameID());
                jRecord.put("frameSeq", frame.getFrameSeq());
                jRecord.put("camField", frame.getCamField());
                jRecord.put("camDist", frame.getCamDist());
                jRecord.put("camX", frame.getCamX());
                jRecord.put("camY", frame.getCamY());
                jRecord.put("camZ", frame.getCamZ());
                jRecord.put("camRX", frame.getCamRX());
                jRecord.put("camRY", frame.getCamRY());
                jRecord.put("camRZ", frame.getCamRZ());
                jRecord.put("command", frame.getCommand());
                jRecord.put("param1", frame.getParam1());
                jRecord.put("param2", frame.getParam2());
                jRecord.put("param3", frame.getParam3());
                jRecord.put("animID", frame.getAnimID().getAnimID());
            }
            else {
                jRecord.put("frameID", "");
                jRecord.put("frameSeq", "");
                jRecord.put("camField", "");
                jRecord.put("camDist", "");
                jRecord.put("camX", "");
                jRecord.put("camY", "");
                jRecord.put("camZ", "");
                jRecord.put("camRX", "");
                jRecord.put("camRY", "");
                jRecord.put("camRZ", "");
                jRecord.put("command", "");
                jRecord.put("param1", "");
                jRecord.put("param2", "");
                jRecord.put("param3", "");
                jRecord.put("animID", "");
            }
            jTabla.add(jRecord);            
        }
        catch (Exception e) {
            System.out.println(e.toString() + " ERROR: Frame Service: getFrame");            
        }
        return JsonConvert.toJSONArray(jTabla);
    }

    public Boolean updateFrame(String frameIDTxt, 
                               String frameSeqTxt, 
                               String camFieldTxt, 
                               String camDistTxt, 
                               String camXTxt, 
                               String camYTxt, 
                               String camZTxt, 
                               String camRXTxt, 
                               String camRYTxt, 
                               String camRZTxt, 
                               String commandTxt, 
                               String param1Txt, 
                               String param2Txt, 
                               String param3Txt,
                               String animIDTxt) {
        Boolean oK = false;
        try {
            //Parameter validation
           Integer frameID = Integer.parseInt(frameIDTxt); 
           Integer frameSeq = Integer.parseInt(frameSeqTxt); 
           Double camField = Double.parseDouble(camFieldTxt); 
           Double camDist = Double.parseDouble(camDistTxt); 
           Double camX = Double.parseDouble(camXTxt); 
           Double camY = Double.parseDouble(camYTxt); 
           Double camZ = Double.parseDouble(camZTxt); 
           Double camRX = Double.parseDouble(camRXTxt); 
           Double camRY = Double.parseDouble(camRYTxt); 
           Double camRZ = Double.parseDouble(camRZTxt); 
           Double param1 = Double.parseDouble(param1Txt); 
           Double param2 = Double.parseDouble(param2Txt); 
           Double param3 = Double.parseDouble(param3Txt);
           Integer animID = Integer.parseInt(animIDTxt);           
            //Instancing 1 side class
            EntityManager em = new Kapcsolat().getEntityManager();
            Anim anim = em.find(Anim.class, animID);
            //Instancing many side class
            Frame frame = new Frame(frameID,
                                    frameSeq,
                                    camField,
                                    camDist,
                                    camX, 
                                    camY,
                                    camZ,
                                    camRX,
                                    camRY,
                                    camRZ,
                                    commandTxt,
                                    param1,
                                    param2,
                                    param3,
                                    anim);
            //Execute query
            oK = frame.updateFrame();            
        }
        catch (Exception e) {
            System.out.println(e.toString() + " ERROR: Frame Service: updateFrame");            
        }
        return oK;
    }    

    public Boolean deleteFrame(String frameIDTxt) {
        Boolean oK = false;
        try {
            //Parameter validation
            Integer frameID = Integer.parseInt(frameIDTxt);
            //Innstancing class
            Frame frame = new Frame(frameID, 
                                    0,
                                    0.0, 
                                    0.0,
                                    0.0,
                                    0.0,
                                    0.0,
                                    0.0,
                                    0.0,
                                    0.0,
                                    " ", 
                                    0.0, 
                                    0.0,
                                    0.0,
                                    null); //All fake except frameID
            //Execute command, success/unsuccess flag
            oK = frame.deleteFrame();            
        }
        catch (Exception e) {
            System.out.println(e.toString() + " ERROR: Frame Service: deleteFrame");            
        }
        return oK;
    }    

    public JSONArray getAllFrame() {
        List <JSONObject> jTabla = new ArrayList();
        try {
            //Static call model class
            List <Frame> frames = Frame.getAllFrame();
            //Operation, success flag
            for(Frame frame: frames) {
                JSONObject jRecord = new JSONObject();
                jRecord.put("frameID", frame.getFrameID());
                jRecord.put("frameSeq", frame.getFrameSeq());
                jRecord.put("camField", frame.getCamField());
                jRecord.put("camDist", frame.getCamDist());
                jRecord.put("camX", frame.getCamX());
                jRecord.put("camY", frame.getCamY());
                jRecord.put("camZ", frame.getCamZ());
                jRecord.put("camRX", frame.getCamRX());
                jRecord.put("camRY", frame.getCamRY());
                jRecord.put("camRZ", frame.getCamRZ());
                jRecord.put("command", frame.getCommand());
                jRecord.put("param1", frame.getParam1());
                jRecord.put("param2", frame.getParam2());
                jRecord.put("param3", frame.getParam3());
                jRecord.put("animID", frame.getAnimID().getAnimID());
                jTabla.add(jRecord);                
            }
            
        }
        catch (Exception e) {
            System.out.println(e.toString() + " ERROR: Frame Service: getAllFrame");            
        }
        return JsonConvert.toJSONArray(jTabla);
    }    

    public JSONArray getAllFrameOfAnim(String animIDTxt) {
        List <JSONObject> jTabla = new ArrayList();
        try {
            //Parameter validation
            Integer animID = Integer.parseInt(animIDTxt);
            //Static call model class
            List <Frame> frames = Frame.getAllFrameOfAnim(animID);
            //Operation, success flag
            for(Frame frame: frames) {
                JSONObject jRecord = new JSONObject();
                jRecord.put("frameID", frame.getFrameID());
                jRecord.put("frameSeq", frame.getFrameSeq());
                jRecord.put("camField", frame.getCamField());
                jRecord.put("camDist", frame.getCamDist());
                jRecord.put("camX", frame.getCamX());
                jRecord.put("camY", frame.getCamY());
                jRecord.put("camZ", frame.getCamZ());
                jRecord.put("camRX", frame.getCamRX());
                jRecord.put("camRY", frame.getCamRY());
                jRecord.put("camRZ", frame.getCamRZ());
                jRecord.put("command", frame.getCommand());
                jRecord.put("param1", frame.getParam1());
                jRecord.put("param2", frame.getParam2());
                jRecord.put("param3", frame.getParam3());
                jRecord.put("animID", frame.getAnimID().getAnimID());
                jTabla.add(jRecord);                
            }
            
        }
        catch (Exception e) {
            System.out.println(e.toString() + " ERROR: Frame Service: getAllFrameofAnim");            
        }
        return JsonConvert.toJSONArray(jTabla);
    }
    
    //Import-export and recompute frames by their given commands and parameters
    public JSONArray produceFrameOfAnim(String animIDTxt, String path) {
        List <JSONObject> jTabla = new ArrayList(); //Production report temp storage
        Frame baseFrame = null; //Base frame marker
        try {
            //Parameter validation
            Integer animID = Integer.parseInt(animIDTxt);
            //Setting path of XML files
            FrameFile.setPath(path);
            //Static call model class
            List <Frame> frames = Frame.getAllFrameOfAnim(animID);
            //Operation, success flag
            for(Frame frame: frames) {
                FrameFile frameFile = new FrameFile(frame); //Frame XML file instance
                JSONObject jRecord = new JSONObject(); //Message temp storage for frame XML file instance
                switch (frame.getCommand()) {
                    case "ImportBase": //Import frame XML, copy its camera settings to frame instance, assign it as base (error if no XML)
                        if (frameFile.importFromFile() != true) { //Try to import frame from XML
                            jRecord.put("msg", " ERROR: Base frame XML file import error: " + frameFile.getFileName());
                            throw new RuntimeException(" ERROR: Base frame XML file import error: " + frameFile.getFileName());
                        }
                        if (frameFile.getFrame().updateFrame() != true) { //Try to update frame entity class from XML file
                            jRecord.put("msg", " ERROR: Frame database table update error at importing base frame: " + frameFile.getFileName());
                            throw new RuntimeException(" ERROR: Frame database table update error at importing base frame: " + frameFile.getFileName());                            
                        }
                        baseFrame = frameFile.getFrame(); //Assign frame as base frame
                        jRecord.put("msg", " SUCCESS: Camera settings of frame XML file are imported, marked as base frame: " + frameFile.getFileName());                        
                    break;
                    case "ManualBase": //Assign frame instance as base, export its camera settings to XML (error if no XML)
                        if (frameFile.exportToFile() != true) { //Try to export frame to XML
                            jRecord.put("msg", " ERROR: Base frame XML file export error: " + frameFile.getFileName());
                            throw new RuntimeException(" ERROR: Base frame XML file export error: " + frameFile.getFileName());
                        }
                        baseFrame = frameFile.getFrame(); //Assign frame as base frame
                        jRecord.put("msg", " SUCCESS: Camera settings of frame are exported to XML file, marked as base frame: " + frameFile.getFileName());                                                
                    break;
                    case "ManualExport": //Export camera settings of frame instance to XML (error if no XML)
                        if (frameFile.exportToFile() != true) { //Try to export frame to XML
                            jRecord.put("msg", " ERROR: Current frame XML file export error: " + frameFile.getFileName());
                            throw new RuntimeException(" ERROR: Current frame XML file export error: " + frameFile.getFileName());
                        }
                        jRecord.put("msg", " SUCCESS: Camera settings of current frame are exported to XML file: " + frameFile.getFileName());                                                                        
                    break;
                    case "Synchronize": //Copy camera settings of base frame into this frame instance (error if no base, no XML), export it to XML
                        if (baseFrame == null) { //If base frame not assigned...
                            jRecord.put("msg", " ERROR: Base frame assignment missing for synchronization of: " + frameFile.getFileName());
                            throw new RuntimeException(" ERROR: Base frame assignment missing for synchronization of: " + frameFile.getFileName());                            
                        }
                        //Copy camera settings from base frame to current one
                        frameFile.getFrame().setCamField(baseFrame.getCamField());
                        frameFile.getFrame().setCamDist(baseFrame.getCamDist());
                        frameFile.getFrame().setCamX(baseFrame.getCamX());
                        frameFile.getFrame().setCamY(baseFrame.getCamY());
                        frameFile.getFrame().setCamZ(baseFrame.getCamZ());
                        frameFile.getFrame().setCamRX(baseFrame.getCamRX());
                        frameFile.getFrame().setCamRY(baseFrame.getCamRY());
                        frameFile.getFrame().setCamRZ(baseFrame.getCamRZ());
                        if (frameFile.getFrame().updateFrame() != true) { //Try to update frame entity class
                            jRecord.put("msg", " ERROR: Frame database table update error at synchronization of: " + frameFile.getFileName());
                            throw new RuntimeException(" ERROR: Frame database table update at synchronization of" + frameFile.getFileName());                            
                        }
                        if (frameFile.exportToFile() != true) { //Try to export frame to XML
                            jRecord.put("msg", " ERROR: XML file export error: " + frameFile.getFileName());
                            throw new RuntimeException(" ERROR: XML file export error: " + frameFile.getFileName());
                        }
                        jRecord.put("msg", " SUCCESS: Camera settings of base frame are copied and exported to XML file: " + frameFile.getFileName());                                                                                                    
                    break;
                    case "Clone": //Copy camera settings of base frame into current, overwrite/create its XML with base XML (error if no base)
                        if (baseFrame == null) { //If base frame not assigned...
                            jRecord.put("msg", " ERROR: Base frame assignment missing for cloning into: " + frameFile.getFileName());
                            throw new RuntimeException(" ERROR: Base frame assignment missing for cloning into: " + frameFile.getFileName());                            
                        }
                        //Copy camera settings from base frame to current one
                        frameFile.getFrame().setCamField(baseFrame.getCamField());
                        frameFile.getFrame().setCamDist(baseFrame.getCamDist());
                        frameFile.getFrame().setCamX(baseFrame.getCamX());
                        frameFile.getFrame().setCamY(baseFrame.getCamY());
                        frameFile.getFrame().setCamZ(baseFrame.getCamZ());
                        frameFile.getFrame().setCamRX(baseFrame.getCamRX());
                        frameFile.getFrame().setCamRY(baseFrame.getCamRY());
                        frameFile.getFrame().setCamRZ(baseFrame.getCamRZ());
                        if (frameFile.getFrame().updateFrame() != true) { //Try to update frame entity class
                            jRecord.put("msg", " ERROR: Frame database table update error at cloning: " + frameFile.getFileName());
                            throw new RuntimeException(" ERROR: Frame database table update error at cloning: " + frameFile.getFileName());                            
                        }
                        FrameFile baseFrameFile = new FrameFile(baseFrame); //Base frame XML file instance
                        if (baseFrameFile.cloneFileTo(frameFile) != true) { //Try to copy base frame XML to current frame XML file
                            jRecord.put("msg", " ERROR: Unsuccessful copy/overwrite of base frame XML file into frame XML file: " + frameFile.getFileName());
                            throw new RuntimeException(" ERROR: Unsuccessful copy/overwrite of base frame XML file into frame XML file: " + frameFile.getFileName());
                        }
                        jRecord.put("msg", " SUCCESS: XML file and camera settings of base frame are copied/overwritten into frame XML file: " + frameFile.getFileName());                                                                                                                            
                    break;
                }
                jTabla.add(jRecord);                
            }
        }
        catch (Exception e) {
            JSONObject jRecord1 = new JSONObject();
            jRecord1.put("msg", " ERROR: Frame Service: produceFrame: possible failure of reading Frame database table");
            jTabla.add(jRecord1);                
            System.out.println(e.toString() + " ERROR: Frame Service: produceFrame: possible failure of reading Frame database table");            
        }
        finally {
            return JsonConvert.toJSONArray(jTabla); //Return production report
        }
    }
}
