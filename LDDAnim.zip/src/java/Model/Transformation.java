package Model;

import java.util.List;
import java.lang.Math;
import java.util.ArrayList;

public class Transformation {
    //Coordinates of rotation center    
    private Double x; 
    private Double y;
    private Double z;
    //Rotations in degrees
    private Double rx; 
    private Double ry;
    private Double rz;

    //Constructor polymorphs
    public Transformation(Double x, Double y, Double z, Double rx, Double ry, Double rz) {
        this.x = x;
        this.y = y;
        this.z = z;
        this.rx = rx;
        this.ry = ry;
        this.rz = rz;
    }

    //Getter-setters
    public Double getX() {
        return x;
    }

    public void setX(Double x) {
        this.x = x;
    }

    public Double getY() {
        return y;
    }

    public void setY(Double y) {
        this.y = y;
    }

    public Double getZ() {
        return z;
    }

    public void setZ(Double z) {
        this.z = z;
    }

    public Double getRx() {
        return rx;
    }

    public void setRx(Double rx) {
        this.rx = rx;
    }

    public Double getRy() {
        return ry;
    }

    public void setRy(Double ry) {
        this.ry = ry;
    }

    public Double getRz() {
        return rz;
    }

    public void setRz(Double rz) {
        this.rz = rz;
    }

    //Import transformation from LDD
    public Boolean fromLDD(List<Double> lddTransformation) {
        Boolean oK = false;
        try {
            this.x = lddTransformation.get(11);
            this.y = lddTransformation.get(10);
            this.z = lddTransformation.get(9);
            Double ryRad = Math.asin(lddTransformation.get(2));
            Double rxRad = Math.asin(-1 * lddTransformation.get(1) / Math.cos(ryRad));
            Double rzRad = Math.asin(-1 * lddTransformation.get(5) / Math.cos(ryRad));
            this.rx = rxRad * 180/ Math.PI;
            this.ry = ryRad * 180/ Math.PI;
            this.rz = rzRad * 180/ Math.PI;
            oK = true;
        }
        catch(Exception e) {
            System.out.println(e.toString() + " ERROR: Import Transformation from LDD failed");
        }
        return oK = true;
    }
    
    //Export transformation to LDD
    public List<Double> toLDD() {
        List<Double> result = null;
        try {
            result = new ArrayList();
            Double rxRad = this.rx * Math.PI / 180;
            Double ryRad = this.ry * Math.PI / 180;
            Double rzRad = this.rz * Math.PI / 180;
            Double sinrxRad = Math.sin(rxRad);
            Double sinryRad = Math.sin(ryRad);
            Double sinrzRad = Math.sin(rzRad);
            Double cosrxRad = Math.cos(rxRad);
            Double cosryRad = Math.cos(ryRad);
            Double cosrzRad = Math.cos(rzRad);
            result.add(cosrxRad * cosryRad);
            result.add(sinrxRad * cosryRad);
            result.add(sinryRad);
            result.add(sinrxRad * cosrzRad + cosrxRad * sinryRad * sinrzRad);
            result.add(cosrxRad * cosrzRad - sinrxRad * sinryRad * sinrzRad);
            result.add(-1 * cosryRad * sinrzRad);
            result.add(sinrxRad * sinrzRad - cosrxRad * sinryRad * cosrzRad);
            result.add(cosrxRad * sinrzRad + sinrxRad * sinryRad * cosrzRad);
            result.add(cosryRad * cosrzRad);
            result.add(this.z);
            result.add(this.y);
            result.add(this.x);            
        }
        catch(Exception e) {
            System.out.println(e.toString() + " ERROR: Export Transformation to LDD failed");
        }
        return result;
    }
}
