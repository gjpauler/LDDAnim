package Model;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.channels.FileChannel;
import java.util.ArrayList;
import java.util.List;
import org.w3c.dom.Document;
import org.w3c.dom.Element;

public class FrameFile {
    //Private properties
    private static String path = "C:/Download/"; //Path of XML files of frames
    private String fileName; //Full XML file name
    private Document document; //DOM of XML file
    private Element camElement; //Camera element of XML file
    private Frame frame; //Frame instance associated

    //Constructor
    public FrameFile(Frame frame) {
        this.fileName = "";
        this.document = null;
        this.camElement = null;
        this.frame = frame;
    }

    //Getters
    public static String getPath() {
        return path;
    }

    public String getFileName() {
        return fileName;
    }

    public Document getDocument() {
        return document;
    }

    public Element getCamElement() {
        return camElement;
    }

    public Frame getFrame() {
        return frame;
    }

    //Setters
    public static void setPath(String path){    
        FrameFile.path = path;
    }

    //CRUD+A
    //Import from XML file to frame instance
    public Boolean importFromFile() {
        Boolean oK = false; //Initiate success flag
        try {
            this.fileName = this.path + this.frame.getAnimID().getTitle() + this.frame.getFrameSeq() + ".XML";
            this.document = XMLHandler.xmlFileToDocument(fileName);
            this.camElement = XMLHandler.nodeListToElementList(XMLHandler.DocumentToNodeList(this.document, "Camera")).get(0);
            this.frame.setCamField(XMLHandler.getDblValuesList(this.camElement, "fieldOfView", 1).get(0));
            this.frame.setCamDist(XMLHandler.getDblValuesList(this.camElement, "distance", 1).get(0));
            Transformation transformation = new Transformation(0.0,0.0,0.0,0.0,0.0,0.0);
            if (transformation.fromLDD(XMLHandler.getDblValuesList(this.camElement, "transformation", 12)) == true) {
                this.frame.setCamX(transformation.getX());
                this.frame.setCamY(transformation.getY());
                this.frame.setCamZ(transformation.getZ());
                this.frame.setCamRX(transformation.getRx());
                this.frame.setCamRY(transformation.getRy());
                this.frame.setCamRZ(transformation.getRz());                
                oK = true; //Set success flag
            }
        }
        catch (Exception e) {
            System.out.println(e.toString() + "XML file to Frame import error: " + this.fileName);
        }
        return oK;
    }

    //Export of frame instance to XML file
    public Boolean exportToFile(){
        List<Double> dblValuesList = new ArrayList();
        Boolean oK = false; //Initiate success flag
        try {
            this.fileName = this.path + this.frame.getAnimID().getTitle() + this.frame.getFrameSeq() + ".XML";
            this.document = XMLHandler.xmlFileToDocument(fileName);
            this.camElement = XMLHandler.nodeListToElementList(XMLHandler.DocumentToNodeList(this.document, "Camera")).get(0);
            dblValuesList.clear();
            dblValuesList.add(this.frame.getCamField());
            this.camElement = XMLHandler.setDblValuesList(dblValuesList, this.camElement, "fieldOfView", 1);
            dblValuesList.clear();
            dblValuesList.add(this.frame.getCamDist());
            this.camElement = XMLHandler.setDblValuesList(dblValuesList, this.camElement, "distance", 1);
            Transformation transformation = new Transformation(this.frame.getCamX(),
                                                               this.frame.getCamY(),
                                                               this.frame.getCamZ(),
                                                               this.frame.getCamRX(),
                                                               this.frame.getCamRY(),
                                                               this.frame.getCamRZ());
            dblValuesList.clear();
            dblValuesList = transformation.toLDD();
            this.camElement = XMLHandler.setDblValuesList(dblValuesList, this.camElement, "transformation", 12);            
            if (XMLHandler.writeDocumentToXMLFile(this.document, this.fileName) == true) {
                oK = true; //Set success flag
            }
        }
        catch (Exception e) {
            System.out.println(e.toString() + "Frame to XML file export error: " + this.fileName);
        }
        return oK;
    }

    //Clone XML file of this frame into existing/nonexisting XML file of other frame
    public Boolean cloneFileTo(FrameFile otherFrameFile){
        Boolean oK = false; //Initiate success flag
        try {
            this.fileName = this.path + this.frame.getAnimID().getTitle() + this.frame.getFrameSeq() + ".XML";
            otherFrameFile.fileName = otherFrameFile.path + otherFrameFile.frame.getAnimID().getTitle() + otherFrameFile.frame.getFrameSeq() + ".XML";
            File file1 = new File(this.fileName);
            if (!file1.exists()) {
                throw new Exception("Error: Source file does not exist: " + this.fileName);
            }
            File file2 = new File(otherFrameFile.fileName);
            if (!file2.exists()) {
                file2.createNewFile();
            }
            FileChannel src = new FileInputStream(file1).getChannel();
            FileChannel dest = new FileOutputStream(file2).getChannel();
            dest.truncate(0);
            dest.transferFrom(src, 0, src.size());
            src.close();
            dest.close();
            oK = true; //Set success flag
        }
        catch (Exception e) {
            System.out.println(e.toString() + "Error cloning from XML file: " + this.fileName + " into XML file: " + otherFrameFile.fileName);
        }
        return oK;
    }
    
}
