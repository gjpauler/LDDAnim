package Model;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Kapcsolat {
    private EntityManagerFactory emf;
    private EntityManager em;
    
    public Kapcsolat() {
        this.emf = Persistence.createEntityManagerFactory("LDDAnimPU");
        this.em = this.emf.createEntityManager();
    }
    
    public EntityManager getEntityManager() {
        return this.em;
    }
}