package Model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

//Entity class
@Entity
//Táblahivatkozás
@Table(name = "anim")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Anim.findAll", query = "SELECT a FROM Anim a")
    , @NamedQuery(name = "Anim.findByAnimID", query = "SELECT a FROM Anim a WHERE a.animID = :animID")
    , @NamedQuery(name = "Anim.findByTitle", query = "SELECT a FROM Anim a WHERE a.title = :title")
    , @NamedQuery(name = "Anim.findByAuthor", query = "SELECT a FROM Anim a WHERE a.author = :author")
    , @NamedQuery(name = "Anim.findByVersion", query = "SELECT a FROM Anim a WHERE a.version = :version")
    , @NamedQuery(name = "Anim.findByFrameCount", query = "SELECT a FROM Anim a WHERE a.frameCount = :frameCount")})
public class Anim implements Serializable {

    @OneToMany(cascade = CascadeType.ALL, mappedBy = "animID")
    private Collection<Frame> frameCollection;
    //Mezőhivatkozások annotációkkal
    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "animID")
    private Integer animID;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 32)
    @Column(name = "title")
    private String title;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 32)
    @Column(name = "author")
    private String author;
    @Basic(optional = false)
    @NotNull
    @Column(name = "version")
    private int version;
    @Basic(optional = false)
    @NotNull
    @Column(name = "frameCount")
    private int frameCount;
    //Auto-generált konstruktor polimorfok
    public Anim() {
    }

    public Anim(Integer animID) {
        this.animID = animID;
    }

    public Anim(Integer animID, String title, String author, int version, int frameCount) {
        this.animID = animID;
        this.title = title;
        this.author = author;
        this.version = version;
        this.frameCount = frameCount;
    }
    //Autogenerált konstruktor polimorfok, törölve ami felesleges
    public Integer getAnimID() {
        return animID;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getAuthor() {
        return author;
    }

    public int getVersion() {
        return version;
    }

    public void setVersion(int version) {
        this.version = version;
    }

    public int getFrameCount() {
        return frameCount;
    }

    public void setFrameCount(int frameCount) {
        this.frameCount = frameCount;
    }
    //Saját írású CRUD+A metódusok
    public Boolean addNewAnim() {
        try {
            //Entity manager példányosítás
            EntityManager em = new Kapcsolat().getEntityManager();
            //Stored proc query példányosítás
            StoredProcedureQuery spq = em.createStoredProcedureQuery("addNewAnim");
            //Paraméterek regisztrációja
            spq.registerStoredProcedureParameter("titleIN", String.class, ParameterMode.IN);
            spq.registerStoredProcedureParameter("authorIN", String.class, ParameterMode.IN);
            spq.registerStoredProcedureParameter("versionIN", Integer.class, ParameterMode.IN);
            spq.registerStoredProcedureParameter("frameCountIN", Integer.class, ParameterMode.IN);
            //Paraméterek értékadása
            spq.setParameter("titleIN", this.title);
            spq.setParameter("authorIN", this.author);
            spq.setParameter("versionIN", this.version);
            spq.setParameter("frameCountIN", this.frameCount);
            //Futtatás
            spq.execute();
            //Sikeres futás output vissaadás
            return Boolean.TRUE;
        }
        catch (Exception e) {
            System.out.println(e.toString() + " Error: Model layer: addNewAnim");
            return Boolean.FALSE;
        }                
    }
    
    public Boolean getAnim() {
        try {
            //Entity manager példányosítás
            EntityManager em = new Kapcsolat().getEntityManager();
            //Stored proc query példányosítás
            StoredProcedureQuery spq = em.createStoredProcedureQuery("getAnim");
            //Paraméterek regisztrációja
            spq.registerStoredProcedureParameter("animIDIN", Integer.class, ParameterMode.IN);
            //Paraméterek értékadása
            spq.setParameter("animIDIN", this.animID);
            //Futtatás
            List <Object[]> animsTable = new ArrayList();
            animsTable = spq.getResultList();
            for(Object[] animRow: animsTable) {
                Integer animID = (Integer)animRow[0];
            }
            Anim animRecord = em.find(Anim.class, animID);
            this.animID = animRecord.animID;
            this.title = animRecord.title;
            this.author = animRecord.author;
            this.version = animRecord.version;
            this.frameCount = animRecord.frameCount;            
            //Sikeres futás output vissaadás
            return Boolean.TRUE;
        }
        catch (Exception e) {
            System.out.println(e.toString() + " Error: Model layer: getAnim");
            return Boolean.FALSE;
        }                
    }
    
    public Boolean updateAnim() {
        try {
            //Entity manager példányosítás
            EntityManager em = new Kapcsolat().getEntityManager();
            //Stored proc query példányosítás
            StoredProcedureQuery spq = em.createStoredProcedureQuery("updateAnim");
            //Paraméterek regisztrációja
            spq.registerStoredProcedureParameter("titleIN", String.class, ParameterMode.IN);
            spq.registerStoredProcedureParameter("versionIN", Integer.class, ParameterMode.IN);
            spq.registerStoredProcedureParameter("frameCountIN", Integer.class, ParameterMode.IN);
            spq.registerStoredProcedureParameter("animIDIN", Integer.class, ParameterMode.IN);
            //Paraméterek értékadása
            spq.setParameter("titleIN", this.title);
            spq.setParameter("versionIN", this.version);
            spq.setParameter("frameCountIN", this.frameCount);
            spq.setParameter("animIDIN", this.animID);
            //Futtatás
            spq.execute();
            //Sikeres futás output vissaadás
            return Boolean.TRUE;
        }
        catch (Exception e) {
            System.out.println(e.toString() + " Error: Model layer: updateAnim");
            return Boolean.FALSE;
        }               
    }
    
    public Boolean deleteAnim() {
        try {
            //Entity manager példányosítás
            EntityManager em = new Kapcsolat().getEntityManager();
            //Stored proc query példányosítás
            StoredProcedureQuery spq = em.createStoredProcedureQuery("deleteAnim");
            //Paraméterek regisztrációja
            spq.registerStoredProcedureParameter("animIDIN", Integer.class, ParameterMode.IN);
            //Paraméterek értékadása
            spq.setParameter("animIDIN", this.animID);
            //Futtatás
            spq.execute();
            //Sikeres futás output vissaadás
            return Boolean.TRUE;
        }
        catch (Exception e) {
            System.out.println(e.toString() + " Error: Model layer: deleteAnim");
            return Boolean.FALSE;
        }        
    }
    
    public static List <Anim> getAllAnim() {
        //Eredménylista sikertelenségi jelzés
        List <Anim> anims = null;
        try {
            //Eredménylista példányosítás
            anims = new ArrayList();
            //Entity manager példányosítás
            EntityManager em = new Kapcsolat().getEntityManager();
            //Stored proc query példányosítás
            StoredProcedureQuery spq = em.createStoredProcedureQuery("getAllAnim");
            //Paraméterek regisztrációja
            //Paraméterek értékadása
            //Futtatás
            List <Object[]> animsTable = new ArrayList();
            animsTable = spq.getResultList();
            //Sikeres futás output vissaadás
            for(Object[] animRow: animsTable) {
                Anim animRecord = new Anim(
                     (Integer)animRow[0],
                     (String)animRow[1],
                     (String)animRow[2],
                     (Integer)animRow[3],
                     (Integer)animRow[4]
                );
                anims.add(animRecord);
            }            
        }
        catch (Exception e) {
            System.out.println(e.toString() + " Error: Model layer: getAllAnim");
        }
        return anims;
    }
    //Auto-generált átdefinálós annotációk
    @Override
    public int hashCode() {
        int hash = 0;
        hash += (animID != null ? animID.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Anim)) {
            return false;
        }
        Anim other = (Anim) object;
        if ((this.animID == null && other.animID != null) || (this.animID != null && !this.animID.equals(other.animID))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Model.Anim[ animID=" + animID + " ]";
    }

    @XmlTransient
    public Collection<Frame> getFrameCollection() {
        return frameCollection;
    }

    public void setFrameCollection(Collection<Frame> frameCollection) {
        this.frameCollection = frameCollection;
    }
    
}
