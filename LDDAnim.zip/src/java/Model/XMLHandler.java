package Model;

import java.io.File;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

public class XMLHandler {

    //Read from given XML file to Document
    public static Document xmlFileToDocument(String xmlFileName) {
        Document document = null;
        try {
            //Build XML connection
            DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
            DocumentBuilder db = dbf.newDocumentBuilder();
            File f = new File(xmlFileName);
            document = db.parse(f);
        }
        catch (Exception e) {
            System.out.println(e.toString() + " Error reading XML file: " + xmlFileName + " into Document");
        }
        return document;
    }

    //Write Document to XML file
    public static Boolean writeDocumentToXMLFile(Document document, String xmlFileName) {
        Boolean oK = false;
        try {
            TransformerFactory tf = TransformerFactory.newInstance(); //Fájl transzformáló gyár
            Transformer t = tf.newTransformer(); //Fájl transzformáló
            DOMSource source = new DOMSource(document); //Levéglegesíti a dokumentum gráfszerkezetet
            File f = new File(xmlFileName); //Célfájl meghatározása
            StreamResult result = new StreamResult(f); //Célfájlba menő adatáram létrehozása
            t.transform(source, result); //Letranszformálás célfájlba
            oK = true;
        }
        catch (Exception e) {
            System.out.println(e.toString() + " Error writing Document into XML file: " + xmlFileName);
        }
        return oK;
    }    
    //Read from Document to NodeList by reference
    public static NodeList DocumentToNodeList(Document document, String rootTag) {
        NodeList nodeList = null;
        try {
            if (document != null) {
                nodeList = document.getElementsByTagName(rootTag);
            }
        }
        catch (Exception e) {
            System.out.println(e.toString() + " Error reading Document into NodeList");
        }
        return nodeList;
    }

    //Read NodeList into list of Element by reference
    public static List<Element> nodeListToElementList(NodeList nodeList) {
        List<Element> elementList = null;
        try {
            if (nodeList != null) {
                elementList = new ArrayList();
                for (Integer i=0; i<nodeList.getLength(); i++) { 
                    elementList.add((Element)nodeList.item(i));
                }
            }
        }
        catch (Exception e) {
            System.out.println(e.toString() + " Error reading NodeList into List of Element");
        }
        return elementList;
    }
    
    //Read List of Double type values with Count length from Attribute of Element
    public static List<Double> getDblValuesList(Element element, String attribute, Integer count) {
        List<Double> dblValuesList = null;
        try {
            dblValuesList = new ArrayList();
            String[] txtValuesArray = element.getAttribute(attribute).split(","); //Vesszővel elválasztott string felvagdalása rész-stringekbe
            for(Integer i=0; i<count; i++) {
                dblValuesList.add(Double.parseDouble(txtValuesArray[i])); //Double-vé konvertált részstringek listába írása
            }
        }
        catch (Exception e) {
            System.out.println(e.toString() + " Error reading double values List from attribute: " + attribute + " of Element");
        }
        return dblValuesList;
    }

    //Read List of Long type values with Count length from Attribute of Element
    public static List<Long> getLngValuesList(Element element, String attribute, Integer count) {
        List<Long> LngValuesList = null;
        try {
            LngValuesList = new ArrayList();
            String[] txtValuesArray = element.getAttribute(attribute).split(","); //Vesszővel elválasztott string felvagdalása rész-stringekbe
            for(Integer i=0; i<count; i++) {
                LngValuesList.add(Long.parseLong(txtValuesArray[i])); //Double-vé konvertált részstringek listába írása
            }
        }
        catch (Exception e) {
            System.out.println(e.toString() + " Error reading long values List from attribute: " + attribute + " of Element");
        }
        return LngValuesList;
    }

    //Write List of Double type values with Count length to Attribute of Element
    public static Element setDblValuesList(List<Double> dblValuesList, Element element, String attribute, Integer count) {
        Element elementOut = null;
        String result = "";
        try {
            Locale locale = new Locale("en","us");
            DecimalFormatSymbols decimalFormatSymbols = new DecimalFormatSymbols(locale);
            DecimalFormat decimalFormat = new DecimalFormat("#0.00000000000000000", decimalFormatSymbols); //17 tizedesjegyes double kiírás beállítása
            elementOut = element; //Bemenő értéket meghivatkozza az output
            for(Integer i=0; i < count; i++) {
                result = result + decimalFormat.format(dblValuesList.get(i)); //17 tizedesre konvertált stringek fűzése
                if(i < count - 1) {
                    result = result + ","; //Szeparátor vesszők fűzése értékek közé, végére nem
                }
            }
            elementOut.setAttribute(attribute, result); //Attributum átállítása
        }
        catch (Exception e) {
            System.out.println(e.toString() + " Error writing double values List: " + result + " to attribute: " + attribute + " of Element");
        }
        return elementOut;
    }

    //Write List of Long type values with Count length to Attribute of Element
    public static Element setLngValuesList(List<Long> LngValuesList, Element element, String attribute, Integer count) {
        Element elementOut = null;
        String result = "";
        try {
            elementOut = element; //Bemenő értéket meghivatkozza az output
            for(Integer i=0; i < count; i++) {
                result = result + LngValuesList.get(i); //konvertált stringek fűzése
                if(i < count - 1) {
                    result = result + ","; //Szeparátor vesszők fűzése értékek közé, végére nem
                }
            }
            elementOut.setAttribute(attribute, result); //Attributum átállítása
        }
        catch (Exception e) {
            System.out.println(e.toString() + " Error writing Long values List: " + result + " to attribute: " + attribute + " of Element");
        }
        return elementOut;
    }
    
}
