package Model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityManager;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.ParameterMode;
import javax.persistence.StoredProcedureQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;

@Entity
@Table(name = "frame")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Frame.findAll", query = "SELECT f FROM Frame f")
    , @NamedQuery(name = "Frame.findByFrameID", query = "SELECT f FROM Frame f WHERE f.frameID = :frameID")
    , @NamedQuery(name = "Frame.findByFrameSeq", query = "SELECT f FROM Frame f WHERE f.frameSeq = :frameSeq")
    , @NamedQuery(name = "Frame.findByCamField", query = "SELECT f FROM Frame f WHERE f.camField = :camField")
    , @NamedQuery(name = "Frame.findByCamDist", query = "SELECT f FROM Frame f WHERE f.camDist = :camDist")
    , @NamedQuery(name = "Frame.findByCamX", query = "SELECT f FROM Frame f WHERE f.camX = :camX")
    , @NamedQuery(name = "Frame.findByCamY", query = "SELECT f FROM Frame f WHERE f.camY = :camY")
    , @NamedQuery(name = "Frame.findByCamZ", query = "SELECT f FROM Frame f WHERE f.camZ = :camZ")
    , @NamedQuery(name = "Frame.findByCamRX", query = "SELECT f FROM Frame f WHERE f.camRX = :camRX")
    , @NamedQuery(name = "Frame.findByCamRY", query = "SELECT f FROM Frame f WHERE f.camRY = :camRY")
    , @NamedQuery(name = "Frame.findByCamRZ", query = "SELECT f FROM Frame f WHERE f.camRZ = :camRZ")
    , @NamedQuery(name = "Frame.findByCommand", query = "SELECT f FROM Frame f WHERE f.command = :command")
    , @NamedQuery(name = "Frame.findByParam1", query = "SELECT f FROM Frame f WHERE f.param1 = :param1")
    , @NamedQuery(name = "Frame.findByParam2", query = "SELECT f FROM Frame f WHERE f.param2 = :param2")
    , @NamedQuery(name = "Frame.findByParam3", query = "SELECT f FROM Frame f WHERE f.param3 = :param3")})
public class Frame implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "frameID")
    private Integer frameID;
    @Basic(optional = false)
    @NotNull
    @Column(name = "frameSeq")
    private int frameSeq;
    @Basic(optional = false)
    @NotNull
    @Column(name = "camField")
    private double camField;
    @Basic(optional = false)
    @NotNull
    @Column(name = "camDist")
    private double camDist;
    @Basic(optional = false)
    @NotNull
    @Column(name = "camX")
    private double camX;
    @Basic(optional = false)
    @NotNull
    @Column(name = "camY")
    private double camY;
    @Basic(optional = false)
    @NotNull
    @Column(name = "camZ")
    private double camZ;
    @Basic(optional = false)
    @NotNull
    @Column(name = "camRX")
    private double camRX;
    @Basic(optional = false)
    @NotNull
    @Column(name = "camRY")
    private double camRY;
    @Basic(optional = false)
    @NotNull
    @Column(name = "camRZ")
    private double camRZ;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 16)
    @Column(name = "command")
    private String command;
    @Basic(optional = false)
    @NotNull
    @Column(name = "param1")
    private double param1;
    @Basic(optional = false)
    @NotNull
    @Column(name = "param2")
    private double param2;
    @Basic(optional = false)
    @NotNull
    @Column(name = "param3")
    private double param3;
    @JoinColumn(name = "animID", referencedColumnName = "animID")
    @ManyToOne(optional = false)
    private Anim animID;

    //Auto-generált konstruktor polimorfok
    public Frame() {
    }

    public Frame(Integer frameID) {
        this.frameID = frameID;
    }

    public Frame(Integer frameID, int frameSeq, double camField, double camDist, double camX, double camY, double camZ, double camRX, double camRY, double camRZ, String command, double param1, double param2, double param3, Anim anim) {
        this.frameID = frameID;
        this.frameSeq = frameSeq;
        this.camField = camField;
        this.camDist = camDist;
        this.camX = camX;
        this.camY = camY;
        this.camZ = camZ;
        this.camRX = camRX;
        this.camRY = camRY;
        this.camRZ = camRZ;
        this.command = command;
        this.param1 = param1;
        this.param2 = param2;
        this.param3 = param3;
        this.animID = anim;
    }
    
    //Auto generált getterek-setterek
    public Integer getFrameID() {
        return frameID;
    }

    public int getFrameSeq() {
        return frameSeq;
    }

    public void setFrameSeq(int frameSeq) {
        this.frameSeq = frameSeq;
    }

    public double getCamField() {
        return camField;
    }

    public void setCamField(double camField) {
        this.camField = camField;
    }

    public double getCamDist() {
        return camDist;
    }

    public void setCamDist(double camDist) {
        this.camDist = camDist;
    }

    public double getCamX() {
        return camX;
    }

    public void setCamX(double camX) {
        this.camX = camX;
    }

    public double getCamY() {
        return camY;
    }

    public void setCamY(double camY) {
        this.camY = camY;
    }

    public double getCamZ() {
        return camZ;
    }

    public void setCamZ(double camZ) {
        this.camZ = camZ;
    }

    public double getCamRX() {
        return camRX;
    }

    public void setCamRX(double camRX) {
        this.camRX = camRX;
    }

    public double getCamRY() {
        return camRY;
    }

    public void setCamRY(double camRY) {
        this.camRY = camRY;
    }

    public double getCamRZ() {
        return camRZ;
    }

    public void setCamRZ(double camRZ) {
        this.camRZ = camRZ;
    }

    public String getCommand() {
        return command;
    }

    public void setCommand(String command) {
        this.command = command;
    }

    public double getParam1() {
        return param1;
    }

    public void setParam1(double param1) {
        this.param1 = param1;
    }

    public double getParam2() {
        return param2;
    }

    public void setParam2(double param2) {
        this.param2 = param2;
    }

    public double getParam3() {
        return param3;
    }

    public void setParam3(double param3) {
        this.param3 = param3;
    }

    public Anim getAnimID() {
        return animID;
    }

    public void setAnimID(Anim animID) {
        this.animID = animID;
    }

    //Saját írású CRUDA-k
    
    //Új Frame létrehozása
    public Boolean addNewFrame() {
        Boolean oK = false;
        try {
            EntityManager em = new Kapcsolat().getEntityManager();
            StoredProcedureQuery spq = em.createStoredProcedureQuery("addNewFrame");
            spq.registerStoredProcedureParameter("animIDIN", Integer.class, ParameterMode.IN);
            spq.registerStoredProcedureParameter("frameSeqIN", Integer.class, ParameterMode.IN);
            spq.registerStoredProcedureParameter("camFieldIN", Double.class, ParameterMode.IN);
            spq.registerStoredProcedureParameter("camDistIN", Double.class, ParameterMode.IN);
            spq.registerStoredProcedureParameter("camXIN", Double.class, ParameterMode.IN);
            spq.registerStoredProcedureParameter("camYIN", Double.class, ParameterMode.IN);
            spq.registerStoredProcedureParameter("camZIN", Double.class, ParameterMode.IN);
            spq.registerStoredProcedureParameter("camRXIN", Double.class, ParameterMode.IN);
            spq.registerStoredProcedureParameter("camRYIN", Double.class, ParameterMode.IN);
            spq.registerStoredProcedureParameter("camRZIN", Double.class, ParameterMode.IN);
            spq.registerStoredProcedureParameter("commandIN", String.class, ParameterMode.IN);
            spq.registerStoredProcedureParameter("param1IN", Double.class, ParameterMode.IN);
            spq.registerStoredProcedureParameter("param2IN", Double.class, ParameterMode.IN);
            spq.registerStoredProcedureParameter("param3IN", Double.class, ParameterMode.IN);
            spq.setParameter("animIDIN", this.animID.getAnimID());
            spq.setParameter("frameSeqIN", this.frameSeq);
            spq.setParameter("camFieldIN", this.camField);
            spq.setParameter("camDistIN", this.camDist);
            spq.setParameter("camXIN", this.camX);
            spq.setParameter("camYIN", this.camY);
            spq.setParameter("camZIN", this.camZ);
            spq.setParameter("camRXIN", this.camRX);
            spq.setParameter("camRYIN", this.camRY);
            spq.setParameter("camRZIN", this.camRZ);
            spq.setParameter("commandIN", this.command);
            spq.setParameter("param1IN", this.param1);
            spq.setParameter("param2IN", this.param2);
            spq.setParameter("param3IN", this.param3);
            spq.execute();
            oK = true;
        }
        catch (Exception e) {
            System.out.println(e.toString() + " QUERY ERROR: Package:Model, Class:Frame, addNewFrame");
        }
        return oK;
    }

    //Frame beolvasása adatbázisból
    public Boolean getFrame() {
        Boolean oK = false;
        try {
            EntityManager em = new Kapcsolat().getEntityManager();
            StoredProcedureQuery spq = em.createStoredProcedureQuery("getFrame");
            spq.registerStoredProcedureParameter("frameIDIN", Integer.class, ParameterMode.IN);
            spq.setParameter("frameIDIN", this.frameID);
            List <Object[]> frameTable = new ArrayList();
            frameTable = spq.getResultList();
            Integer frameIDBuffer = 0;
            for(Object[] frameRow: frameTable) {
                frameIDBuffer = (Integer)frameRow[0];
            }
            Frame frameRecord = em.find(Frame.class, frameIDBuffer);
            this.frameID = frameRecord.frameID;
            this.animID = frameRecord.animID;
            this.frameSeq = frameRecord.frameSeq;
            this.camField = frameRecord.camField;
            this.camDist = frameRecord.camDist;
            this.camX = frameRecord.camX;
            this.camY = frameRecord.camY;
            this.camZ = frameRecord.camZ;
            this.camRX = frameRecord.camRX;
            this.camRY = frameRecord.camRY;
            this.camRZ = frameRecord.camRZ;
            this.command = frameRecord.command;
            this.param1 = frameRecord.param1;
            this.param2 = frameRecord.param2;
            this.param3 = frameRecord.param3;
            oK = true;
        }
        catch (Exception e) {
            System.out.println(e.toString() + " QUERY ERROR: Package:Model, Class:Frame, getFrame");
        }
        return oK;
    }

    //Frame adatok frissítése adatbázisba
    public Boolean updateFrame() {
        Boolean oK = false;
        try {
            EntityManager em = new Kapcsolat().getEntityManager();
            StoredProcedureQuery spq = em.createStoredProcedureQuery("updateFrame");
            spq.registerStoredProcedureParameter("animIDIN", Integer.class, ParameterMode.IN);
            spq.registerStoredProcedureParameter("frameSeqIN", Integer.class, ParameterMode.IN);
            spq.registerStoredProcedureParameter("camFieldIN", Double.class, ParameterMode.IN);
            spq.registerStoredProcedureParameter("camDistIN", Double.class, ParameterMode.IN);
            spq.registerStoredProcedureParameter("camXIN", Double.class, ParameterMode.IN);
            spq.registerStoredProcedureParameter("camYIN", Double.class, ParameterMode.IN);
            spq.registerStoredProcedureParameter("camZIN", Double.class, ParameterMode.IN);
            spq.registerStoredProcedureParameter("camRXIN", Double.class, ParameterMode.IN);
            spq.registerStoredProcedureParameter("camRYIN", Double.class, ParameterMode.IN);
            spq.registerStoredProcedureParameter("camRZIN", Double.class, ParameterMode.IN);
            spq.registerStoredProcedureParameter("commandIN", String.class, ParameterMode.IN);
            spq.registerStoredProcedureParameter("param1IN", Double.class, ParameterMode.IN);
            spq.registerStoredProcedureParameter("param2IN", Double.class, ParameterMode.IN);
            spq.registerStoredProcedureParameter("param3IN", Double.class, ParameterMode.IN);
            spq.registerStoredProcedureParameter("frameIDIN", Integer.class, ParameterMode.IN);
            spq.setParameter("animIDIN", this.animID.getAnimID());
            spq.setParameter("frameSeqIN", this.frameSeq);
            spq.setParameter("camFieldIN", this.camField);
            spq.setParameter("camDistIN", this.camDist);
            spq.setParameter("camXIN", this.camX);
            spq.setParameter("camYIN", this.camY);
            spq.setParameter("camZIN", this.camZ);
            spq.setParameter("camRXIN", this.camRX);
            spq.setParameter("camRYIN", this.camRY);
            spq.setParameter("camRZIN", this.camRZ);
            spq.setParameter("commandIN", this.command);
            spq.setParameter("param1IN", this.param1);
            spq.setParameter("param2IN", this.param2);
            spq.setParameter("param3IN", this.param3);
            spq.setParameter("frameIDIN", this.frameID);
            spq.execute();            
            oK = true;
        }
        catch (Exception e) {
            System.out.println(e.toString() + " QUERY ERROR: Package:Model, Class:Frame, updateFrame");
        }
        return oK;
    }

    //Frame törlése adatbázisból
    public Boolean deleteFrame() {
        Boolean oK = false;
        try {
            EntityManager em = new Kapcsolat().getEntityManager();
            StoredProcedureQuery spq = em.createStoredProcedureQuery("deleteFrame");
            spq.registerStoredProcedureParameter("frameIDIN", Integer.class, ParameterMode.IN);
            spq.setParameter("frameIDIN", this.frameID);
            spq.execute();            
            oK = true;
        }
        catch (Exception e) {
            System.out.println(e.toString() + " QUERY ERROR: Package:Model, Class:Frame, deleteFrame");
        }
        return oK;
    }

    //Minden Frame listázása
    public static List <Frame> getAllFrame() {
        List <Frame> frames = null;
        try {
            frames = new ArrayList();
            EntityManager em = new Kapcsolat().getEntityManager();
            StoredProcedureQuery spq = em.createStoredProcedureQuery("getAllFrame");
            List <Object[]> frameTable = new ArrayList();
            frameTable = spq.getResultList();
            for(Object[] frameRow: frameTable) {
                Frame frameRecord = new Frame();
                frameRecord.frameID = (Integer)frameRow[0];
                Anim anim = new Anim((Integer)frameRow[1]);
                if (anim.getAnim() != false) {
                    frameRecord.animID = anim;
                }
                else {
                    throw new RuntimeException(" QUERY ERROR: Package:Model, Class:Frame, getAllFrame: referenced AnimID does not exist: "+anim.getAnimID());
                }
                frameRecord.frameSeq = (Integer)frameRow[2];
                frameRecord.camField = (Double)frameRow[3];
                frameRecord.camDist = (Double)frameRow[4];
                frameRecord.camX = (Double)frameRow[5];
                frameRecord.camY = (Double)frameRow[6];
                frameRecord.camZ = (Double)frameRow[7];
                frameRecord.camRX = (Double)frameRow[8];
                frameRecord.camRY = (Double)frameRow[9];
                frameRecord.camRZ = (Double)frameRow[10];
                frameRecord.command = (String)frameRow[11];
                frameRecord.param1 = (Double)frameRow[12];
                frameRecord.param2 = (Double)frameRow[13];
                frameRecord.param3 = (Double)frameRow[14];                           
                frames.add(frameRecord);
            }            
        }
        catch (Exception e) {
            System.out.println(e.toString() + " QUERY ERROR: Package:Model, Class:Frame, getAllFrame");
        }
        return frames;
    }

    //Egy Anim minden Frame-jének listázása
    public static List <Frame> getAllFrameOfAnim(Integer animID) {
        List <Frame> frames = null;
        try {
            frames = new ArrayList();
            EntityManager em = new Kapcsolat().getEntityManager();
            StoredProcedureQuery spq = em.createStoredProcedureQuery("getAllFrameOfAnim");
            spq.registerStoredProcedureParameter("animIDIN", Integer.class, ParameterMode.IN);
            spq.setParameter("animIDIN", animID);
            List <Object[]> frameTable = new ArrayList();
            frameTable = spq.getResultList();
            for(Object[] frameRow: frameTable) {
                Frame frameRecord = new Frame();
                frameRecord.frameID = (Integer)frameRow[0];
                Anim anim = new Anim((Integer)frameRow[1]);
                if (anim.getAnim() != false) {
                    frameRecord.animID = anim;
                }
                else {
                    throw new RuntimeException(" QUERY ERROR: Package:Model, Class:Frame, getAllFrameOfAnim: referenced AnimID does not exist: "+anim.getAnimID());
                }
                frameRecord.frameSeq = (Integer)frameRow[2];
                frameRecord.camField = (Double)frameRow[3];
                frameRecord.camDist = (Double)frameRow[4];
                frameRecord.camX = (Double)frameRow[5];
                frameRecord.camY = (Double)frameRow[6];
                frameRecord.camZ = (Double)frameRow[7];
                frameRecord.camRX = (Double)frameRow[8];
                frameRecord.camRY = (Double)frameRow[9];
                frameRecord.camRZ = (Double)frameRow[10];
                frameRecord.command = (String)frameRow[11];
                frameRecord.param1 = (Double)frameRow[12];
                frameRecord.param2 = (Double)frameRow[13];
                frameRecord.param3 = (Double)frameRow[14];                           
                frames.add(frameRecord);
            }            
            
        }
        catch (Exception e) {
            System.out.println(e.toString() + " QUERY ERROR: Package:Model, Class:Frame, getAllFrameOfAnim ");
        }
        return frames;
    }

    //Autogenerált annotációk
    
    @Override
    public int hashCode() {
        int hash = 0;
        hash += (frameID != null ? frameID.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Frame)) {
            return false;
        }
        Frame other = (Frame) object;
        if ((this.frameID == null && other.frameID != null) || (this.frameID != null && !this.frameID.equals(other.frameID))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "Model.Frame[ frameID=" + frameID + " ]";
    }
    
}
