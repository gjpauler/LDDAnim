package Controller;

import Service.FrameService;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.json.JSONObject;

public class FrameServlet extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json"); //Set message format
        PrintWriter out = response.getWriter(); //Assign text output to web browser
        try { //Default try
            //Instancing service class
            FrameService frameService = new FrameService();
            //Temp storage for response
            JSONObject obj = new JSONObject();
            if (request.getParameter("task") != null) { //If there is task from frontend...
                //Manually writen CRUD+A handlers
                if (request.getParameter("task").equals("addNewFrame")) { //If task is Add new frame...
                    if(frameService.addNewFrame( //Calling method of service class instance
                        request.getParameter("frameID"), 
                        request.getParameter("frameSeq"), 
                        request.getParameter("camField"), 
                        request.getParameter("camDist"),
                        request.getParameter("camX"),
                        request.getParameter("camY"),
                        request.getParameter("camZ"),
                        request.getParameter("camRX"),
                        request.getParameter("camRY"),
                        request.getParameter("camRZ"),
                        request.getParameter("command"),
                        request.getParameter("param1"),
                        request.getParameter("param2"),
                        request.getParameter("param3"),
                        request.getParameter("animID")
                    )) {
                        obj.put("msg", "Success: FrameServlet: addNewFrame: " + request.getParameter("frameID")); //Success signal
                    }
                    else {
                        obj.put("msg", "Error: FrameServlet: addNewFrame: " + request.getParameter("frameID")); //Error signal
                    }
                    out.write(obj.toString()); //Converting signal to text for frontend                    
                }
                if (request.getParameter("task").equals("getFrame")) { //If task is get frame...
                    out.write(frameService.getFrame(request.getParameter("frameID")).toString());  //Result converted to text for frontend                    
                }
                if (request.getParameter("task").equals("updateFrame")) { //If task is update frame...
                    if(frameService.updateFrame( //Calling method of service class instance
                        request.getParameter("frameID"), 
                        request.getParameter("frameSeq"), 
                        request.getParameter("camField"), 
                        request.getParameter("camDist"),
                        request.getParameter("camX"),
                        request.getParameter("camY"),
                        request.getParameter("camZ"),
                        request.getParameter("camRX"),
                        request.getParameter("camRY"),
                        request.getParameter("camRZ"),
                        request.getParameter("command"),
                        request.getParameter("param1"),
                        request.getParameter("param2"),
                        request.getParameter("param3"),
                        request.getParameter("animID")
                    )) {
                        obj.put("msg", "Success: FrameServlet: updateFrame: " + request.getParameter("frameID")); //Success signal
                    }
                    else {
                        obj.put("msg", "Error: FrameServlet: updateFrame: " + request.getParameter("frameID")); //Error signal
                    }
                    out.write(obj.toString()); //Converting signal to text for frontend                                        
                }
                if (request.getParameter("task").equals("deleteFrame")) { //If task is delete frame...
                    if(frameService.deleteFrame( //Calling method of service class instance
                        request.getParameter("frameID") 
                    )) {
                        obj.put("msg", "Success: FrameServlet: deleteFrame: " + request.getParameter("frameID")); //Success signal
                    }
                    else {
                        obj.put("msg", "Error: FrameServlet: deleteFrame: " + request.getParameter("frameID")); //Error signal
                    }
                    out.write(obj.toString()); //Converting signal to text for frontend                                                            
                }
                if (request.getParameter("task").equals("getAllFrame")) { //If task is get all frame...
                    out.write(frameService.getAllFrame().toString());  //Result converted to text for frontend                                        
                }
                if (request.getParameter("task").equals("getAllFrameOfAnim")) { //If task is get all frame of anim...
                    out.write(frameService.getAllFrameOfAnim(request.getParameter("animID")).toString());  //Result converted to text for frontend                                                            
                }
                if (request.getParameter("task").equals("produceFrameOfAnim")) { //If task is produce frame...
                    out.write(frameService.produceFrameOfAnim(request.getParameter("animID"),request.getParameter("path")).toString());  //Result converted to text for frontend                                                                                
                }                
            }
        }
        catch (Exception e) { //If unidentified error...
            out.write(e.toString() + " Error: Unidentified FrameServlet error"); //Default error message
        }                    
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
