package Controller;

import Model.User;
import Service.UserService;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.json.JSONObject;

public class UserServlet extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json"); //Message format set to json
        PrintWriter out = response.getWriter(); //Direct text output to browser
        try {
            //Create userservice instance
            UserService userService = new UserService();            
            if (request.getParameter("task") != null) { //If valid task...
                if (request.getParameter("task").equals("login")) { //If task is login...
                    String userName = "";
                    String password = "";
                    userName = request.getParameter("userName"); //Collect data from request
                    password = request.getParameter("password");
                    JSONObject retrieve = new JSONObject();
                    User user = userService.login(userName, password); //Search for user
                    if (user != null) { //If valid user...
                        request.getSession().setAttribute("user", user); //Copy user data into session
                        retrieve.put("msg", "1"); //Success flag
                    } else { //If invalid user
                        retrieve.put("msg", "0"); //failure flag
                    }
                    out.write(retrieve.toString());
                }
                if (request.getParameter("task").equals("isLoggedUser")) { //If task is isLoggedUser...
                    User user = (User)request.getSession().getAttribute("user"); //Search for user in session
                    JSONObject retrieve = new JSONObject();
                    if (user != null) { //If user found...
                        retrieve.put("userName", user.getUserName()); //Copy user data into reply
                        retrieve.put("msg", "1"); //Success flag
                    } else { //If user not found...
                        retrieve.put("msg", "0"); //failure flag                        
                    }
                    out.write(retrieve.toString());                    
                }
                if (request.getParameter("task").equals("logout")) { //If task is logout...
                    request.getSession().setAttribute("user", null); //Kill user in session
                    User user = (User)request.getSession().getAttribute("user"); //Search for user in session
                    JSONObject retrieve = new JSONObject();
                    if (user == null) { //If user not found...
                        retrieve.put("msg", "1"); //Success flag
                    } else { //If user found...
                        retrieve.put("msg", "0"); //failure flag                        
                    }
                    out.write(retrieve.toString());                                        
                }
                if (request.getParameter("task").equals("register")) { //If task is register...
                    String userName = "";
                    String password = "";
                    String email = "";
                    userName = request.getParameter("userName"); //Collect data from request
                    password = request.getParameter("password");
                    email = request.getParameter("email");
                    JSONObject retrieve = new JSONObject();
                    if (userService.isRegistered(userName, password, email) == 0) { //No matching registered user found...
                        String givenName = "";
                        String surName = "";
                        String address = "";
                        String city = "";
                        String zip = "";
                        String country = "";
                        givenName = request.getParameter("givenName");
                        surName = request.getParameter("surName");
                        address = request.getParameter("address");
                        city = request.getParameter("city");
                        zip = request.getParameter("zip");
                        country = request.getParameter("country");
                        User user = userService.addNewUser(userName, 
                                                        password, 
                                                        email, 
                                                        givenName,
                                                        surName,
                                                        address,
                                                        city,
                                                        zip,
                                                        country
                                                        );
                        if (user != null) {
                            retrieve.put("msg", "1"); //Success flag
                        } else {
                            retrieve.put("msg", "0"); //failure flag                                                    
                        }
                    } else { //If matching user already registered...
                        retrieve.put("msg", "0"); //failure flag                        
                    }
                    out.write(retrieve.toString());                                                            
                }
            }
        }
        catch (Exception e) { //General UserServlet error
            out.write(e.toString() + " ERROR: Unidentified UserServlet error");
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
