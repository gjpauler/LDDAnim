package Controller;

import Service.AnimService;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import org.json.JSONObject;

public class AnimServlet extends HttpServlet {

    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("application/json"); //Set message format
        PrintWriter out = response.getWriter(); //Assign text output to browser
        try { //Default try...
            //Instancing service class
            AnimService animService = new AnimService();
            //Temp storage for response
            JSONObject obj = new JSONObject();
            if (request.getParameter("task") != null) { //If there is task from frontend...
                //Manually writen CRUD+A handlers
                if (request.getParameter("task").equals("addNewAnim")) {
                    if(animService.addNewAnim( //Calling method of service class instance
                        request.getParameter("title"), 
                        request.getParameter("author"), 
                        request.getParameter("version"), 
                        request.getParameter("frameCount")
                    )) {
                        obj.put("msg", "Servlet:Successful addNewAnim: " + request.getParameter("title")); //Success signal
                    }
                    else {
                        obj.put("msg", "Error:Servlet: addNewAnim: " + request.getParameter("title")); //Error signal
                    }
                    out.write(obj.toString()); //Converting signal to text for frontend
                }
                if (request.getParameter("task").equals("getAnim")) {
                    out.write(animService.getAnim(request.getParameter("animID")).toString());  //Result converted to text for frontend                                        
                }
                if (request.getParameter("task").equals("updateAnim")) {
                    if(animService.updateAnim( //Calling method of service class instance
                        request.getParameter("animID"), 
                        request.getParameter("title"), 
                        request.getParameter("version"), 
                        request.getParameter("frameCount")
                    )) {
                        obj.put("msg", "Servlet:Successful updateAnim: " + request.getParameter("animID")); //Success signal
                    }
                    else {
                        obj.put("msg", "Error:Servlet: updateAnim: " + request.getParameter("animID")); //Error signal
                    }
                    out.write(obj.toString()); //Converting signal to text for frontend                    
                }
                if (request.getParameter("task").equals("deleteAnim")) {
                    if(animService.deleteAnim( //Calling method of service class instance
                        request.getParameter("animID") 
                    )) {
                        obj.put("msg", "Servlet:Successful deleteAnim: " + request.getParameter("animID")); //Success signal
                    }
                    else {
                        obj.put("msg", "Error:Servlet: deleteAnim: " + request.getParameter("animID")); //Error signal
                    }
                    out.write(obj.toString()); //Converting signal to text for frontend                    
                }
                if (request.getParameter("task").equals("getAllAnim")) {
                    out.write(animService.getAllAnim().toString());  //Result converted to text for frontend                                                            
                }
            }            
        }
        catch (Exception e) { //If unidentified error...
            out.write(e.toString() + " Error: Unidentified AnimServlet error"); //Default error message
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
